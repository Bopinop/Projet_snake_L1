Rémi Tribouillard
Erwan Dorniol

Erwan Dorniol : réalisation des 4 premiers exercices
Rémi Tribouillard : modification des 4 premiers exercices et réalisation de l'interface graphique ainsi que l'insertion d'une musique.

Nous avons créée 3 structures (Grille, Serpent, Liste_section).
Quand le serpent mange un fruit, le serpent gagne entre 1 et 5 unité de taille et, la section est insérée au début.
Quand il touche un mur ou touche son corps, le jeu est terminé et vous avez perdu.
Le serpent ce déplace avec les touches directionnelles.
Pour accélérer le jeu, il faut appuyer sur p.
Pour ralentir le jeu, il faut appuyer sur m.
Pour choisir les dimensions de la grille, il faut entrer en argument du programme -size x y ou x=longeur et y=largeur.
Pour choisir la couleur du serpent, il faut entrer en argument du programme -color x y z ou x=nuance de rouge, y=nuance de vert et z=nuance de bleu.
Pour faire clignoter les bordures, il faut entrer en argument du programme -star.
Pour activer l'easter egg, il faut entrer en argument du programme -ee (PS : pour l'avoir, manger au moins 1 fruit).
